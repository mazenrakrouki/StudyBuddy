package com.example.studybuddy;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.ArrayList;
import java.util.List;

public class ParticipantsActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ParticipantsAdapter adapter;
    private DatabaseReference databaseRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_participants);

        String sessionId = getIntent().getStringExtra("sessionId");
        databaseRef = FirebaseDatabase.getInstance().getReference()
                .child("sessions").child(sessionId).child("participants");

        recyclerView = findViewById(R.id.recyclerViewParticipants);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        loadParticipants();
    }

    private void loadParticipants() {
        databaseRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                List<String> participantIds = new ArrayList<>();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    participantIds.add(snapshot.getKey());
                }
                loadUserDetails(participantIds);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Gérer l'erreur
            }
        });
    }

    private void loadUserDetails(List<String> userIds) {
        DatabaseReference usersRef = FirebaseDatabase.getInstance().getReference("users");
        List<User> participants = new ArrayList<>();
        final int[] loadedCount = {0};

        if (userIds.isEmpty()) {
            updateAdapter(participants);
            return;
        }

        for (String userId : userIds) {
            usersRef.child(userId).addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot snapshot) {
                    User user = snapshot.getValue(User.class);
                    if (user != null) {
                        user.setUserId(snapshot.getKey());
                        participants.add(user);
                    }
                    if (++loadedCount[0] == userIds.size()) {
                        updateAdapter(participants);
                    }
                }

                @Override
                public void onCancelled(DatabaseError error) {
                    if (++loadedCount[0] == userIds.size()) {
                        updateAdapter(participants);
                    }
                }
            });
        }
    }

    private void updateAdapter(List<User> participants) {
        adapter = new ParticipantsAdapter(participants);
        recyclerView.setAdapter(adapter);
    }
}