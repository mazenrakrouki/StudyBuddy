package com.example.studybuddy;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class StudentSessionAdapter extends RecyclerView.Adapter<StudentSessionAdapter.ViewHolder> {

    private List<StudySession> sessions;
    private String currentUserId;
    private OnJoinClickListener joinClickListener;

    public interface OnJoinClickListener {
        void onJoinClick(StudySession session);
    }

    public StudentSessionAdapter(List<StudySession> sessions, String userId, OnJoinClickListener listener) {
        this.sessions = sessions;
        this.currentUserId = userId;
        this.joinClickListener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_student_session, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        StudySession session = sessions.get(position);

        // Afficher les données de la session
        holder.textSubject.setText(session.getSubject());
        holder.textDescription.setText(session.getDescription());
        holder.textLevel.setText(session.getLevel());
        holder.textDate.setText(session.getDate());
        holder.textLocation.setText(session.getLocation());

        // Gérer l'état du bouton
        if (session.getParticipants().containsKey(currentUserId)) {
            holder.btnJoin.setText("Déjà inscrit");
            holder.btnJoin.setEnabled(false);
        } else {
            holder.btnJoin.setText("Rejoindre");
            holder.btnJoin.setEnabled(true);
        }

        holder.btnJoin.setOnClickListener(v -> {
            if (joinClickListener != null) {
                joinClickListener.onJoinClick(session);
            }
        });
    }

    @Override
    public int getItemCount() {
        return sessions.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView textSubject, textDescription, textLevel, textDate, textLocation;
        Button btnJoin;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            textSubject = itemView.findViewById(R.id.textSubject);
            textDescription = itemView.findViewById(R.id.textDescription);
            textLevel = itemView.findViewById(R.id.textLevel);
            textDate = itemView.findViewById(R.id.textDate);
            textLocation = itemView.findViewById(R.id.textLocation);
            btnJoin = itemView.findViewById(R.id.btnJoin);
        }
    }
}